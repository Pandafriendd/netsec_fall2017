
from .PacketType   import PacketType, FIELD_NOT_SET