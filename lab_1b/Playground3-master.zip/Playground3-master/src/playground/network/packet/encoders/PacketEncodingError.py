
class PacketEncodingError(Exception):
    pass